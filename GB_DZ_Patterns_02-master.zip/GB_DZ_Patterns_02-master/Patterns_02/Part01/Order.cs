﻿namespace Patterns_02
{
    /// <summary>
    /// Класс объекта Order
    /// </summary>
    class Order
    {
        int orderId;
        string Name;
    }
}
