﻿namespace Patterns_02
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
